# Simple Table
Add a table to your website

The Simple Table App is similar to an Excel table, but easier. Add as many columns and rows as you’d like and tailor your table to the design of your website with a custom background color. The app allows for multiple table styles including basic, header, banded, and column. So forget the hassle of importing an Excel table and add the Simple Table app to your website.